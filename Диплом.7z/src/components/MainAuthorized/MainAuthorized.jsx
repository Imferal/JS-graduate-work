import React from 'react';
import MasonryInfiniteScroller from 'react-masonry-infinite';
import s from './MainAuthorized.module.scss';

const MainAuthorized = props => {
  // debugger;
  return (
    <main className={s.main__container}>
      <MasonryInfiniteScroller
        hasMore={false}
        loadMore={props.fetchMoreData}
        // loadMore={() => {
        //   alert ('Ку-ку!');
        // }}
      >

        {props.photos}

      </MasonryInfiniteScroller>

      <button className={s.main__moreCats}>More cats!</button>
    </main>
  );
};

export default MainAuthorized;
