import React from 'react';
import s from './Header.module.scss';

export default function Header () {
  return (
    <header className={s.header__wrapper}>
      <div className={s.header__body}>
        <div className={s.header__loginText}>Вы не вошли в систему</div>
        <button
          className={s.header__loginButton}
          onClick={() => alert ('Click!')}
        >
          login
        </button>
      </div>
    </header>
  );
}
