import React from 'react';
import s from './Main.module.scss';

export default function Main (props) {
  return (
    <main className={s.main__container}>
      <div className={s.main__box}>
        <img
          src={props.state.greetPhoto.url}
          alt={props.state.greetPhoto.description}
        />
        <h1 className={s.main__greetings}>
          Котики вас не знают. Пожалуйста, войдите на сайт.
        </h1>
      </div>
    </main>
  );
}
