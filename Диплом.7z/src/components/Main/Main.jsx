import React from 'react';
import s from './Main.module.scss';

function Main (props) {
  // debugger;

  let unsplashImages = <p>Фотографии загружаются...</p>;

  if (props.state.isLoaded === true) {
    unsplashImages = props.state.serverData.results.map ((el, i) => {
      return (
        <img id={el.id} src={el.urls.full} alt={el.alt_description} key={i} />
      );
    });
  }

  // console.log (unsplashImages);
  // debugger;

  return (
    <div className={s.main__wrapper}>
      {unsplashImages}

    </div>
  );
}

export default Main;
