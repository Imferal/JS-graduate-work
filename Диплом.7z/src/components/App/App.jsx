import React from 'react';
import s from './App.module.scss';

import Header from '../Header/Header';
import Main from '../Main/Main';
import Footer from '../Footer/Footer';

export default function App (props) {
  return (
    <div className={s.app__wrapper}>
      <Header state={props.state} dispatch={props.dispatch} />
      <Main state={props.state} dispatch={props.dispatch} />
      <Footer />
    </div>
  );
}
