import React from 'react';
import ReactDOM from 'react-dom';

import './index.scss';

import App from './components/App/App';
import store from './redux/store';

import {loadPhotosCreator, loadLocalCreator} from './redux/reducer';
// debugger;
store.dispatch (loadLocalCreator ());
store.dispatch (loadPhotosCreator ());

// import {loadPhotosCreator, loginCreator} from './redux/reducer';
// store.dispatch (loginCreator ());

let rerender = () => {
  ReactDOM.render (
    <React.StrictMode>
      <App state={store.getState ()} dispatch={store.dispatch.bind (store)} />
    </React.StrictMode>,
    document.getElementById ('root')
  );
};

// Rerender page at first time
rerender (store.getState);

//
//
//
//
//
//
//
//
//

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
// import * as serviceWorker from './serviceWorker';
// serviceWorker.unregister ();
